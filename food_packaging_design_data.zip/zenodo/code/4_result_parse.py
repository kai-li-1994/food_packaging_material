"""
Purpose:
This script normalizes and parses scraped packaging-material attributes
to reconstruct polymer combinations, laminate structures, and attached
components, and to compute design-level material-share indicators.

Method:
- Normalizes raw material text using a comprehensive library of
  regular-expression rules to standardize polymer names and separators.
- Parses normalized strings into monomaterial, multilayer laminate,
  or material-plus-component structures based on commercial packaging
  notation conventions.
- Identifies attached components (e.g. caps, lids, valves) and records
  component materials and component–body material matching.
- Aggregates parsed offerings to compute four design-level indicators:
  packaging-composition share, layer-complexity share,
  component-presence share, and recycling-incompatibility share.

Outputs:
- Structured datasets supporting the figures and tables in the Results section.
- Summary files reporting material shares by packaging keyword and CN product group.

Context:
This script constitutes the analytical core of the study, translating
scraped listing attributes into quantitative evidence on material use,
structural complexity, and recyclability alignment in global food packaging.

Author:
Kai Li, Chair of Operations Management, RWTH Aachen University

Contact:
k.li@om.rwth-aachen.de
"""
# %% Importing packages
import pandas as pd
import re
from collections import defaultdict
from collections import Counter
import math
from itertools import product
import glob
import os
import pickle
# %% 1. Regex
CANON_RULES = [
    # --- Metals & Foils ---
    (re.compile(
        r'\b('
        # --- Foil forms ---
        r'Al\s*foil(s)?|'
        r'Alu\s*foil(s)?|'
        r'Alum\s*foil(s)?|'
        r'Al(?:uminum|uminium|umanium)\s*foil(s)?|'
        # --- Alloy text forms ---
        r'Al\s*alloy(s)?|'
        r'Alu\s*alloy(s)?|'
        r'Alum\s*alloy(s)?|'
        r'Alumin(?:um|ium)\s*alloy(s)?|'
        # --- Alloy code forms ---
        r'Al\s*(8006|8011|8079)[-\s]?(?:O|H14|H18|H24|H26)?|'
        r'Al\s*alloy\s*(8006|8011|8079)[-\s]?(?:O|H14|H18|H24|H26)?|'
        r'AA\s*(8006|8011|8079)[-\s]?(?:O|H14|H18|H24|H26)?|'
        r'EN\s*AW[-\s]?(8006|8011|8079)[-\s]?(?:O|H14|H18|H24|H26)?|'
        # --- Generic aluminum mentions ---
        r'Al|Alu|Alum|Al(?:uminum|uminium|umanium))\b',re.I),"AL"),
    
    (re.compile(r'\b(steel|stainless\s*steel|ss)\b', re.I), "STEEL"),
    (re.compile(r'\b(tinplate|tin\s*foil(s)?|tin\s*plate)\b', re.I), "TIN"),
    (re.compile(r'\b(metal)\b', re.I), "METAL"),
    (re.compile(r'\b(iron)\b', re.I), "IRON"),
    # --- Springs ---
    (re.compile(r'\b(pocket\s*spring|bonnell\s*spring|continuous\s*spring|'
                r'innerspring|coil\s*spring|spring)\b', re.I), "SPRING"),
    # --- Fibres & bio-based materials ---
    (re.compile(r'\b(paper)\b', re.I), "PAPER"),
    (re.compile(r'\b(pulp|wood\s*pulp|bamboo\s*pulp)\b', re.I), "PULP"),
    (re.compile(r'\b(wood|timber|pine)\b', re.I), "WOOD"),
    (re.compile(r'\bcork\b', re.I), "CORK"),
    (re.compile(r'\bbamboo\b', re.I), "BAMBOO"),
    (re.compile(r'\b(starch|corn\s*starch)\b', re.I), "STARCH"),
    (re.compile(r'\b(straw|crop\s*stalk)\b', re.I), "STRAW"),
    (re.compile(r'\b(pes|polyester)\b', re.I), "PES"),
    (re.compile(r'\b(micro\s*fiber(s)?)\b', re.I), "MICROFIBER"),
    (re.compile(r'\b(cotton)\b', re.I), "COTTON"),
    (re.compile(r'\b(linen)\b', re.I), "LINEN"),
    (re.compile(r'\b(wool|cashmere)\b', re.I), "WOOL"),
    (re.compile(r'\b(tencel|lyocell)\b', re.I), "LYOCELL"),
    (re.compile(r'\b(viscose|rayon)\b', re.I), "VISCOSE"),
    (re.compile(r'\b(down)\b', re.I), "DOWN"),
    (re.compile(r'\b(coir|coconut\s*coir|coconut\s*fiber)\b', re.I), "COIR"),
    (re.compile(r'\b(silk)\b', re.I), "SILK"),
    (re.compile(r'\b(leather|suede)\b', re.I), "LEATHER"),
    
    # --- Glass ---
    (re.compile(r'\b(glass)\b', re.I), "GLASS"),
    
    # --- Polyolefins & polyethylene family (foam forms)---
    (re.compile(r'\bepe\b', re.I), "EPE"),     # Expanded Polyethylene
    (re.compile(r'\bxpe\b', re.I), "XPE"),     # Crosslinked Polyethylene
    (re.compile(r'\bixpe\b', re.I), "IXPE"),   # Irradiation-Crosslinked Polyethylene
    (re.compile(r'\bepp\b', re.I), "EPP"),     # Expanded Polypropylene
    (re.compile(r'\bxpp\b', re.I), "XPP"),     # Crosslinked Polypropylene
    (re.compile(r'\bixpp\b', re.I), "IXPP"),   # Irradiation-Crosslinked Polypropylene
    
    # --- Polyolefins & polyethylene family ---
    (re.compile(r'\b(hdpe|high[-\s]?density\s*polyethylene)\b', re.I), "HDPE"),
    (re.compile(r'\b(lldpe|linear[-\s]?low[-\s]?density\s*polyethylene)\b',
                re.I), "LLDPE"),
    (re.compile(r'\b(ldpe|low[-\s]?density\s*polyethylene)\b', re.I), "LDPE"),
    (re.compile(r'\b(pe|polyethylene|polythene)\b', re.I), "PE"),
    (re.compile(r'\b(pp|polypropylene|polyproplynene)\b', re.I), "PP"),
    # --- Metallocene Polyethylene (high-performance sealant PE) ---
    (re.compile(r'\b(m[-\s]*pe|metallocene\s*pe|m\s*ldpe|m\s*lldpe)\b', re.I), "MPE"),
    
    # --- PET family ---
    (re.compile(r'\b(petg|polyethylene\s*terephthalate\s*glycol)\b', re.I), "PETG"),
    (re.compile(r'\b(copet|co\s*pet)\b', re.I), "COPET"),
    (re.compile(r'\b(pet|polyethylene\s*terephthalate|pete|'
                r'polyethyleneterephthalate)\b', re.I), "PET"),
    
    # --- Polyamide / nylon family ---

    (re.compile(r'\b(pa\d*|nylon\d*|ny\d*|poly[-\s]?amide\d*)\b', re.I), "PA"),
    
    # --- Oriented Films (mechanically stretched polymer films) ---
    # Each token represents a family of monoaxially, biaxially, or co-oriented variants
    # derived from the same base polymer. Orientation enhances mechanical strength,
    # clarity, and barrier properties, which are critical for packaging performance.
    (re.compile(r'\b(opp|bopp|mopp|mbopp|copp)\b', re.I), "BOPP"),   # Oriented polypropylene film family
    (re.compile(r'\b(opet|bopet)\b', re.I), "BOPET"),                # Oriented PET film
    (re.compile(r'\b(opa|bopa)\b', re.I), "BOPA"),                   # Oriented nylon film 
    (re.compile(r'\b(bope|mdope)\b', re.I), "BOPE"),
    (re.compile(r'\b(ops)\b', re.I), "OPS"),                         # Oriented polystyrene film

    # --- Metallized Films (polymer films coated with aluminum layer) ---
    # These include vacuum-metallized variants of oriented films such as PET and BOPP,
    # widely used for high-barrier food packaging. The “VM” prefix denotes vacuum metallization,
    # while “MET” and “MPET” are common shorthand for metallized PET films.
    (re.compile(r'\b(alu[-\s]*pet|al[-\s]*pet|met\s*pet|metpet|mpet|vmpet)\b', 
                re.I), "VMPET"),     # Metallized PET / polyester films
    (re.compile(r'\b(vm\s*opp|vmopp|vm\s*bopp|vmbopp)\b', re.I), "VMBOPP"),# Metallized oriented polypropylene films
    (re.compile(r'\b(vm\s*bopet|vmbopet)\b', re.I), "VMBOPET"),            # Metallized oriented PET films (redundant forms)
    
    # --- Others / engineering plastics ---
    (re.compile(r'\bcpp\b', re.I), "CPP"),
    (re.compile(r'\b(ps|polystyrene)\b', re.I), "PS"),
    (re.compile(r'\beps\b', re.I), "EPS"),
    (re.compile(r'\bxps\b', re.I), "XPS"),
    (re.compile(r'\b(pvc|polyvinyl\s*chloride)\b', re.I), "PVC"),
    (re.compile(r'\b(pvdc|polyvinylidene\s*chloride)\b', re.I), "PVDC"),
    (re.compile(r'\b(pbt|polybutylene\s*terephthalate)\b', re.I), "PBT"),
    (re.compile(r'\b(pom|polyoxymethylene)\b', re.I), "POM"),
    (re.compile(r'\b(pc|polycarbonate)\b', re.I), "PC"),
    (re.compile(r'\b(pmma|acrylic|polymethyl\s*methacrylate)\b', re.I), "PMMA"),
    (re.compile(r'\b(eva|ethylene[-\s]*vinyl\s*acetate)\b', re.I), "EVA"),
    (re.compile(r'\b(evoh|ethylene[-\s]*vinyl\s*alcohol)\b', re.I), "EVOH"),
    (re.compile(r'\b(pla|polylactic\s*acid)\b', re.I), "PLA"),
    (re.compile(r'\b(abs|acrylonitrile\s*butadiene\s*styrene)\b', re.I), "ABS"),
    (re.compile(r'\b(asa|acrylonitrile\s*styrene\s*acrylate)\b', re.I), "ASA"),
    (re.compile(r'\b(memory\s*foam|sponge|pu|pu\s*foam|polyurethane|high\s*density\s*foam)\b', re.I), "PU"),
    
    # --- Elastomers---
    (re.compile(r'\b(silicone)\b', re.I), "SILICONE"),
    (re.compile(r'\b(tpe|tpr)\b', re.I), "TPE"),
    (re.compile(r'\b(rubber)\b', re.I), "RUBBER"),
    (re.compile(r'\b(latex|natural\s*latex)\b', re.I), "LATEX"),
    (re.compile(r'\b(poe|polyolefin\s*elastomer)\b', re.I), "POE"),
    (re.compile(r'\b(tpu|thermoplastic\s*polyurethane)\b', re.I), "TPU"),
    
    (re.compile(r'\b(pla|polylactide)\b', re.I), "PLA"),
    (re.compile(r'\b(pbat|polybutylene\s*adipate\s*terephthalate)\b', re.I), "PBAT"),
    (re.compile(r'\b(pha|polyhydroxyalkanoate(s)?)\b', re.I), "PHA"),

    # --- Recycled / flags ---
    (re.compile(r'\b(rpet)\b', re.I), "rPET"),
    (re.compile(r'\b(recycled\s*pp)\b', re.I), "rPP"),
    
    (re.compile(r'\b(plastic)\b', re.I), "PLASTIC"),
]

# Derive all canonical tokens automatically
ALL_TOKENS = sorted({canon for (_, canon) in CANON_RULES})

MATERIAL_TOKEN_PATTERN = re.compile(
    r'\b(' + '|'.join(map(re.escape, ALL_TOKENS)) + r')\b',
    re.I
)

def describe_pattern(pat: re.Pattern) -> str:
    """
    Convert a compiled regex (from CANON_RULES) into a human-readable description
    for tables or SI documentation. Handles plurals, spacing, hyphens, and digits.
    """
    text = pat.pattern
    # 1. Remove word boundaries
    text = text.replace(r'\b', '')
    
    # 3.4 Handle non-capturing optional groups like (?:O|H14|H18|H24|H26)?
    # → (O / H14 / H18 / H24 / H26)
    text = re.sub(
        r'\(\?:([A-Za-z0-9|]+)\)\?',
        lambda m: f"({m.group(1).replace('|', ' / ')})",
        text
    )
    # 2. Simplify non-capturing groups
    text = text.replace('(?:', '(')
    # 3. Plurals: convert (?:s)? or s? to (s)
    text = re.sub(r'\(\?:s\)\?', '(s)', text)
    text = re.sub(r's\?', '(s)', text)
    text = text.replace('(s)?', '(s)')
    
    # 4. Spacing & connectors
    text = re.sub(r'\\s\*', ' (zero or more spaces) ', text)
    text = re.sub(r'\\s\+', ' (one or more spaces) ', text)
    text = re.sub(r'\\s\?', ' (zero or one space) ', text)
    text = re.sub(r'\[-\\s\]\?', '(hyphen or space or none)', text)
    text = re.sub(r'\[-\s\]\?', '(hyphen or space or none)', text)
    text = re.sub(r'\[-\\s\]\*', '(zero or more hyphens or spaces)', text)
    text = re.sub(r'\[-\s\]\*', '(zero or more hyphens or spaces)', text)
    # 5. Numeric patterns
    # Replace \d+, \d*, \d? with clear wording
    # Replace \d quantifiers with clear parenthetical expressions
    text = re.sub(r'\\d\+', '(one or more digits)', text)
    text = re.sub(r'\\d\*', '(zero or more digits)', text)
    text = re.sub(r'\\d\?', '(zero or one digit)', text)
    # Handle explicit numeric braces {2,4}
    text = re.sub(r'\\d\{(\d+),(\d+)\}', r'(digits \1 to \2 times)', text)
    text = re.sub(r'\\d\{(\d+)\}', r'(\1 digits)', text)
    # 6. Alternation '|' → '/'
    text = text.replace('|', ' / ')
    # 7. Clean escaping
    text = text.replace('\\', '')
    # 8. Remove redundant outer parentheses
    text = re.sub(r'^\((.*?)\)$', r'\1', text)
    # 9. Normalize spacing
    text = re.sub(r'\s+', ' ', text).strip()
    # 10. Insert space if digits follow letters or parentheses
    text = re.sub(r'(?<=[A-Za-z\)])digits', ' digits', text)

    return text

desc_rows = []
for regex, canon in CANON_RULES:
    desc_rows.append({
        "material token": canon,
        "pattern": regex.pattern,
        "matched_terms": describe_pattern(regex)
    })

df = pd.DataFrame(desc_rows).drop_duplicates("material token")
# %% 2. Normalization
# Load empirical laminate reference (only once)
df_com = pd.read_csv("./results/df_ext_comp_off.csv")[["sub_share_type", "total_weight"]]
COMBINATION_REF  = dict(zip(df_com["sub_share_type"], df_com["total_weight"]))

def _normalize_combination_from_commas(t: str, min_tokens=3, weight_threshold=1.0):
    """
    Detect cases like 'PET, AL, PE' or 'PET;AL;PE' that likely represent
    known material combinations (not just laminates).
    If such a combination exists in the empirical reference data with 
    total_weight > threshold, normalize it to '+'-joined canonical form.
    """
    if not isinstance(t, str):
        return t
    txt = t.strip().upper()

    # Skip if already structured (/, +)
    if any(sep in txt for sep in ['/', '+']):
        return t

    # Only process clean material token lists separated by ',' or ';'
    if not re.fullmatch(r'([A-Z0-9]{2,8}\s*[;,]\s*)+[A-Z0-9]{2,8}', txt):
        return t

    # Normalize separators → treat ',' and ';' the same
    txt = txt.replace(';', ',')
    tokens = [tok.strip() for tok in txt.split(',') if tok.strip()]
    if len(tokens) < min_tokens:
        return t

    # Sort tokens alphabetically to match canonical order in df_ext_comp_off
    combo_sorted = '+'.join(sorted(tokens))

    # Lookup in empirical combination reference
    if combo_sorted in COMBINATION_REF and COMBINATION_REF[combo_sorted] > weight_threshold:
        return combo_sorted  # Confirmed empirical combination

    return t

def _normalization(s: str) -> str:  # Checks if s is of type 'str'
    if not isinstance(s, str):
        return ""  # if not 'str' then blank string and move on
    t = s
    for pat, canon in CANON_RULES: #  apply normalization rules 
        t = pat.sub(canon, t)
    t = re.sub(r'\\', '/', t)   # normalize backslash to slash before removing symbols
    t = t.replace("，", ",").replace("；", ",").replace(";", ",") # convert all commas/semicolons (Chinese & English) to commas
    t = re.sub(r'\s*\d+(\.\d+)?\s*%', '', t) # remove “100%”, “ 80 %”
    t = re.sub(r'\b\d+(\.\d+)?\s*(g|gsm)\b', '', t, flags=re.I) # removes any weight-related information, like “50 g”, “250gsm”, or “80 GSM”, from the text.
    t = re.sub(r'\s*&\s*', '/', t)  # normalize '&' → '/'
    t = re.sub(r'\b([A-Z]{2,6})\s*-\s*([A-Z]{2,6})\b', r'\1/\2', t) # hyphen to slash ('PET -PE'/'PET- PE'/'PET-PE'->'PET/PE')
    t = re.sub(r'\b([A-Z]{2,6})\s*or\s*([A-Z]{2,6})\b',  r'\1,\2', t) # 'or' in between ('PET orPE'/'PETor PE'/'PETorPE'->'PET,PE')
    t = re.sub(r'\s+or\s+', ',', t, flags=re.I) # General fallback if “or” appears elsewhere (separating clauses)
    t = re.sub(r'[^A-Za-z/\+\-,;\s]', ' ', t) # keep only letters, numbers, valid separators, and whitespace.

    t = re.sub(r'\s+', ' ', t).strip() # replace one or more spaces into one and remove leading and trailing spaces
    t = re.sub(r'\s*\+\s*', '+', t) # remove spaces surrounded by '+'

    #t = re.sub(r'\\', '/', t)   # normalize backslash to slash before removing symbols
    def space_replacer(match):
        before = match.group(1)
        after = match.group(2)
        if MATERIAL_TOKEN_PATTERN.fullmatch(before.upper()) and MATERIAL_TOKEN_PATTERN.fullmatch(after.upper()):
            return before + ',' + after
        else:
            return before + ' ' + after

    pattern = re.compile(r'(\b[A-Za-z0-9]+\b)\s+(\b[A-Za-z0-9]+\b)') # finds two alphanumeric “words” separated by a space
    while True:
        new_t = pattern.sub(space_replacer, t)# replace using a function
        if new_t == t:
            break
        t = new_t
    t = _normalize_combination_from_commas(t, min_tokens=3, weight_threshold=1.0)

    # if not re.search(r'[+/,:]', t): # Only if there are no other separators (+, /, ,) → replace spaces by commas
    #     t = t.replace(' ', ',')
    return t
# %% 3. Parse
# Option & layer splitters
OPTION_SPLIT = re.compile(r'\s*[,]\s*')  # split options by commas/semicolons
LAYER_SPLIT = re.compile(r'\s*[/+]\s*')  # split layers by / or +
FOOD_GRADE_PATTERN = re.compile(r'\b(food\s*grade|fda\s*grade|food[- ]?safe)\b', re.I)
COMPONENT_KEYWORDS = re.compile(
    r'\b(valve|cap|lid|closure|spout|nozzle|zipper|zip lock|seal|liner|collar|handle|cover|pump)\b',
    re.I
)

def parse(s: str, row=None):
    """
    Parse packaging material strings with human-mimic logic.

    Returns:
        dict with:
          - options: list of laminate stacks (each = one option, as list)
          - options_str: list of canonical laminate strings
          - layer_counts: number of layers per laminate
          - flat_materials: list of all materials (flattened, for frequency analysis)
          - food_grade: bool
          - component_context: bool or None
          - component_materials: set or None
    """
    # --- 1: Basic sanity check
    if not isinstance(s, str) or not s.strip():
        return {
            "original": s,
            "options": [], "options_str": [],
            "layer_counts": [], "materials": set(),
            "flat_materials": [],
            "food_grade": False,
            "component_context": None,
            "component_materials": None
        }

    # --- 2: Normalization and flag detection
    s_norm = _normalization(s)
    food_grade = bool(FOOD_GRADE_PATTERN.search(s_norm))

    # --- 3: Split into options
    options_raw = OPTION_SPLIT.split(s_norm)
    options = options_raw if options_raw else [s_norm]

    parsed_options, component_context, component_materials = [], None, set()

    # --- 4: Main parsing loop per option
    for opt in options:
        if not opt.strip():
            continue

        # Case A: only "/" or only "+" (purely laminate / layered structure)
        if ("/" in opt) ^ ("+" in opt):  # XOR: only one separator type present
            layers_raw = LAYER_SPLIT.split(opt)
            layers = []

            for lr in layers_raw:
                # 1. Extract material tokens from this segment
                tokens = [m.group(0).upper() for m in MATERIAL_TOKEN_PATTERN.finditer(lr)]

                # 1.5 Handle component-only mentions with unclear material
                if not tokens:
                    if COMPONENT_KEYWORDS.search(lr):
                        component_context = True
                        component_materials.add("UNCLEAR")  # ✅ still record it
                    continue

                # 2. Check if this segment refers to a component (e.g., cap, lid, spout)
                if COMPONENT_KEYWORDS.search(lr):
                    component_context = True
                    component_materials.update(tokens)
                    continue  # ✅ skip adding component tokens to laminate/body

                # 3. Otherwise, treat as normal laminate/body part
                layers.extend(tokens)       

            # 4. Append only non-empty laminate/body layers to parsed options
            if layers:
                if len(layers) > 1 and len(set(layers)) == 1:                  # ✅ NEW RULE: collapse duplicate identical tokens if all layers are the same
                    layers = [layers[0]]  # interpret as monomaterial, not multilayer
                parsed_options.append(layers)
    
        # --- Case B: mixed "/" and "+" → complex laminate or component patterns
        elif "/" in opt and "+" in opt:
            # Split by plus to get laminate groups
            groups = opt.split("+")
            token_groups = [[m.group(0).upper() for m in MATERIAL_TOKEN_PATTERN.finditer(g)] for g in groups]

            # Classify groups: those containing "/" vs. simple single layers
            laminates = [tg for g, tg in zip(groups, token_groups) if "/" in g]
            simples   = [tg for g, tg in zip(groups, token_groups) if "/" not in g]

            # Count separator dominance
            plus_count  = opt.count("+")
            slash_count = opt.count("/")

            # ---- 1: All groups are laminates → joined laminate
            if len(laminates) == len(groups):
                merged = [mat for sub in token_groups for mat in sub]
                parsed_options.append(merged)

            # ---- 2: One simple + ≥1 laminates → laminate + component
            elif len(simples) == 1 and len(laminates) >= 1:
                leftover = simples[0]
                laminate_parts = laminates

                # Detect component hints (internal first, then row context)
                if any(COMPONENT_KEYWORDS.search(g) for g in groups):
                    component_context = True
                elif row is not None and any(
                    COMPONENT_KEYWORDS.search(v)
                    for v in row.values if isinstance(v, str)
                ):
                    component_context = True
                else:
                    component_context = False
                component_materials.update(leftover)

                # Merge all laminate parts into a single multilayer film
                merged_laminate = [mat for sub in laminate_parts for mat in sub]
                parsed_options.append(merged_laminate)

            # ---- 3: Plus-dominant laminate with one slash-group
            elif len(laminates) == 1 and len(simples) > 1 and plus_count > slash_count:
                main_layers = [mat for sub in simples for mat in sub]
                alt_layer   = laminates[0]

                preliminary = [main_layers + [alt] for alt in alt_layer]

                def has_duplicate(lst):
                    return len(lst) != len(set(lst))

                # Detect impossible duplicates → reinterpret '/' as option separator
                if any(has_duplicate(p) for p in preliminary):
                    sides = opt.split("/")
                    if len(sides) == 2:
                        side_tokens = [
                            [m.group(0).upper() for m in MATERIAL_TOKEN_PATTERN.finditer(s)]
                            for s in sides
                        ]
                        if len(side_tokens[0]) == len(side_tokens[1]) and \
                           not has_duplicate(side_tokens[0]) and \
                           not has_duplicate(side_tokens[1]):
                            for tokens in side_tokens:
                                parsed_options.append(tokens)
                            continue

                # Otherwise, keep laminate-with-variant interpretation
                for alt in alt_layer:
                    parsed_options.append(main_layers + [alt])

            # ---- 4: Otherwise → ambiguous / mixed → conservative cross-product
            else:
                for combo in product(*token_groups):
                    parsed_options.append(list(combo))

        # --- Case C: single token
        else:
            tokens = [m.group(0).upper() for m in MATERIAL_TOKEN_PATTERN.finditer(opt)]
            
            if not tokens:
                continue

            # Check for component-related words in the original text segment
            if COMPONENT_KEYWORDS.search(opt):
                component_context = True
                component_materials.update(tokens)
                # Do NOT add this to parsed_options – it's a component only
            else:
                # Normal monomaterial body (not a component)
                parsed_options.append(tokens)

    # --- 5: Deduplicate identical laminate options (keep order)
    unique_options = []
    for opt in parsed_options:
        if opt not in unique_options:
            unique_options.append(opt)
    parsed_options = unique_options
    
    # --- 6: Generate canonical string versions (layer-order-insensitive)
    canonical_options = []
    for opt in parsed_options:
        # Only keep non-empty material names
        clean_layers = [m for m in opt if isinstance(m, str) and m.strip()]
        if not clean_layers:
            continue

        # Canonicalize by sorting alphabetically (ignore order)
        canon_str = "+".join(sorted(clean_layers))
        canonical_options.append(canon_str)

    # --- 7: Derive layer counts for each laminate
    layer_counts = [len(opt) for opt in parsed_options]
    
    # --- 8: Component–Body Material Match Indicator (strict DfR version) ----------
    # "Same material" only if:
    #   - body is monomaterial
    #   - component is monomaterial
    #   - both materials are identical

    if component_materials:
        # normalise to clean strings
        body_set = {str(m).strip() for m in canonical_options if m}
        comp_set = {str(c).strip() for c in component_materials if c}

        # monomaterial = exactly one distinct material
        is_monomaterial_body = len(body_set) == 1
        is_monomaterial_comp = len(comp_set) == 1

        if is_monomaterial_body and is_monomaterial_comp and body_set == comp_set:
            # strict DfR "same material"
            component_match_body = True
        else:
            # anything else (laminates, different polymers, etc.) counts as "different"
            component_match_body = False
    else:
        # no component reported → no match indicator
        component_match_body = None

    # --- Final structured output
    return {
        "original": s_norm,
        "options": parsed_options,
        "options_str": canonical_options,
        "layer_counts": layer_counts,
        "food_grade": food_grade,
        "component_context": component_context,
        "component_materials": component_materials if component_materials else None,
        "component_match_body": component_match_body,
    }
# %% 4. Column selection
def _column_selection(row, candidate_cols):
    """
    Select the best (richest) material-related column from a single row.

    This function evaluates multiple candidate columns within one product listing
    (e.g., Title, Attributes, Description) and identifies the column most likely
    to contain detailed packaging-material information.

    Scoring logic:
        score = material_count + 0.5 * (val.count("/") + val.count("+"))
        # Additional rule:
        # If a column lists 5+ materials separated only by commas (no '/' or '+'),
        # set score = 0, as it likely represents an unstructured enumeration.

    Args:
        row : pandas.Series
            A single product listing (one row from the scraped dataframe).
        candidate_cols : list of str
            The columns to consider for material information.

    Returns:
        tuple: (source_column_name, material_parsed, best_score)
            source_column_name → name of the chosen column (str or None)
            material_parsed → parse() output (dict)
            best_score → numeric score (float)
    """
    source_column_name, material_parsed, best_score = None, None, -1

    for col in candidate_cols:
        val = row.get(col, None)
        if not isinstance(val, str) or not val.strip():
            continue

        parsed = parse(val, row=row)
        # Calculate total number of recognized materials on the fly
        material_count = sum(len(opt) for opt in parsed.get("options", []))

        if material_count == 0:
            score = 0  # de-prioritize non-material columns
        else:
            sep_count = val.count("/") + val.count("+")
            comma_count = val.count(",")

            # Base weighting: prioritize material richness
            score = material_count + 0.5 * sep_count

            # 🚫 Rule: too many comma-only materials → meaningless enumeration
            if sep_count == 0 and comma_count >= 4 and material_count >= 5:
                score = 0

        if score > best_score:
            parsed_clean = {k: v for k, v in parsed.items()
                            if k not in ("original", "options")}
            source_column_name, material_parsed, best_score = col, parsed_clean, score
            
    if best_score <= 0:
        return None, None, 0
    return source_column_name, material_parsed, best_score
# %% 5. Share computation preparation   
def keyword_file_process(file_path):
    """
    Process one scraped packaging-material file end-to-end:
     1. Read data and detect best material column.
     2. Parse material strings with human-mimic logic.
     3. Expand parsed outputs into analytic columns.
     4. Add offering- and sales-based weights.
     
    Parameters
    ----------
    file_path : str
        Path to the scraped CSV file (e.g. 'flat_merged_attributes_urls_packaging_frozen_meat_500.csv')

    Returns
    -------
    pd.DataFrame
        A standardized, expanded DataFrame ready for share analysis.
    """

    df = pd.read_csv(file_path)

    keep_cols = [
        "count", "page", "url", "title", "highlighted_tokens", "highlight_count",
        "url_collecting_time", "attribute_fetch_time", "sold"
    ]
    exclude_cols = {"liner type", "type of shipping", "seal type", "sealing type", "cap material",'metal type'}
    candidate_cols = [
        c for c in df.columns
        if isinstance(c, str)
        and ("material" in c.lower() or "type" in c.lower())
        and c.lower() not in exclude_cols
    ]

    results = df.apply(
        lambda row: pd.Series(_column_selection(row, candidate_cols)),
        axis=1
    )
    results.columns = ["source_column_name", "material_parsed", "best_score"] 
    df = pd.concat([df, results], axis=1)

    df["source_column_content"] = df.apply( 
        lambda row: (row.get(row["source_column_name"])),axis=1)


    df["options_str"] = df["material_parsed"].apply(
        lambda x: x.get("options_str", []) if isinstance(x, dict) else []
    )
    
    df_final = df[
        [c for c in (keep_cols + ["source_column_name","source_column_content",
         "material_parsed","options_str"]) if c in df.columns]].copy()
    
    df_final["layer_counts"] = df_final["material_parsed"].apply(
        lambda x: x.get("layer_counts", []) if isinstance(x, dict) else []
    )
    df_final["is_laminate"] = df_final["layer_counts"].apply(
        lambda lst: any(n > 1 for n in lst) if lst else False
    )
    df_final["has_component"] = df_final["material_parsed"].apply(
        lambda x: bool(x.get("component_context")) if isinstance(x, dict) else False
    )
    
    df_final["component_match_body"] = df_final["material_parsed"].apply(
    lambda x: x.get("component_match_body", None) if isinstance(x, dict) else None)

    df_final["food_grade"] = df_final["material_parsed"].apply(
        lambda x: x.get("food_grade", False) if isinstance(x, dict) else False
    )
    
    df_final["sold"] = (
        df_final["sold"].astype(str).str.extract(r"(\d+)")[0].astype(float)
    )
    
    df_final["w_sales"] = df_final.apply(lambda r: (
        (r["sold"] / max(len(r["options_str"]), 1))
        if pd.notna(r["sold"]) else 0.0),axis=1)

    df_final["w_offering"] = df_final["options_str"].apply(
        lambda lst: 1.0 / max(len(lst), 1))

    return df, df_final
# %% 6. Share computation   
def compute_design_shares(file_path):
    """
    Compute weighted packaging-design shares across multiple structural
    dimensions from Alibaba B2B listing data, returning both a unified
    long-format share table and a separate metadata summary.
    Logic by dimension

    Overview
    --------
    This function quantifies the distribution of packaging-material designs
    across four key structural dimensions relevant to Design for Recycling (DfR):
        
        1) Packaging composition (material combinations)
        2) Layer complexity (number of laminate layers)
        3) Component presence and component materials
        4) Non-recyclable material presence

    Each indicator is evaluated under two weighting perspectives:

      • Offering-weighted  → supply-side perspective.
        Each unique laminate offering is treated equally, reflecting the
        diversity of packaging designs made available by suppliers.

      • Sales-weighted     → demand-side perspective.
        Each offering is weighted by its reported sales quantity, reflecting
        how often each design is actually purchased.

    The function also returns a small metadata table summarizing dataset
    coverage (number of listings, number of parsed offerings, coverage ratios,
    and total reported sales).

    Analytical structure
    --------------------
    Input DataFrame:
        Must contain parsed laminate structures, component flags, and
        weighting columns `w_offering` and `w_sales` generated by the
        preceding pipeline step (`keyword_file_process()`).

    Internal workflow:
        1. Create two analytical views:
            - Listing-level: one row per product listing.
            - Offering-level: one row per laminate (exploded view of
              `options_str` and `layer_counts`).

        2. Compute share tables for:
            • Packaging composition (unique combinations of materials)
            • Layer complexity (monomaterial / 2-layer / multi-layer)
            • Component presence (with vs. without component)
            • Component material composition
            • Component–body material match (same vs. different material)
            • Non-recyclable presence (recyclable vs. containing
              non-recyclable core)
            • Non-recyclable material breakdown (e.g., metallized, halogenated)

        3. Generate metadata including:
            - Total number of listings and offerings
            - Number and share of successfully parsed offerings
            - Number and share of offerings with available sales data
            - Total reported sales volume

        4. Combine all share tables into a single long-format DataFrame
           (`df_shares_flat`) with the following columns:
               ['share_tab', 'dimension', 'category', 'count', 'weight', 'share']

           where:
             • 'share_tab'  → indicator group (e.g., 'composition', 'layer_complexity')
             • 'dimension'  → weighting type ('offering' or 'sales')
             • 'category'   → grouping variable (e.g., 'PET+PE', 'monomaterial')
             • 'count'      → number of listings/offerings per category
             • 'weight'     → weighted sum of offerings or sales
             • 'share'      → normalized proportion of total weight

        5. Metadata is stored as a separate DataFrame (`df_metadata`)
           with two columns ['meta_key', 'meta_value'].

    Parameters
    ----------
    df_final : pandas.DataFrame
        Processed dataset containing parsed laminate structures, component
        information, and weighting columns. It is the cleaned output of
        `keyword_file_process()`.

    Returns
    -------
    tuple :
        (df_shares_flat, df_listings, df_offerings, df_metadata)

        df_shares_flat : pandas.DataFrame
            Unified long-format table containing all computed shares
            across all dimensions. Each row represents one material or
            structural category under a specific weighting scheme.

        df_listings : pandas.DataFrame
            Listing-level table (one product listing per row), used mainly
            for component-related computations.

        df_offerings : pandas.DataFrame
            Offering-level table (one laminate per row), obtained by
            exploding the material combinations in `options_str`.

        df_metadata : pandas.DataFrame
            Two-column summary table with dataset coverage and diagnostic
            statistics

    """
    df_raw, df_final = keyword_file_process(file_path)
    
    match = re.search(r"_packaging_(.+?)_\d{3}_", file_path)
    packaging_type = match.group(1) if match else os.path.basename(
                                      file_path).replace(".csv", "")
    # ------------------------------------------------------------------
    # Helper for weighting shares (now merge-ready)
    # ------------------------------------------------------------------
    def _weighted_summary(df, group_col, weight_col, total_weight=None,
                          share_type=None, dimension=None):
        """
        Summarize weighted share by sub_share_type, returning a tidy long-format DataFrame.
        """
        if df.empty:
            return pd.DataFrame(columns=["share_type", "dimension", 
                         "sub_share_type", "count", "weight", "share"])

        # Compute weighted sums and counts
        counts = df[group_col].value_counts()
        weighted = (
            df.groupby(group_col)[weight_col]
              .sum()
              .sort_values(ascending=False)
        )
        denom = weighted.sum() if total_weight is None else total_weight
        share = (weighted / denom) if denom > 0 else pd.Series(dtype=float)

        result = pd.concat([
            weighted.rename("weight"),
            counts.rename("count"),
            share.rename("share")
        ], axis=1).fillna(0)

        result = result.reset_index().rename(columns={
                        result.index.name or "index": "sub_share_type"})
    
        result["share_type"] = share_type
        result["dimension"] = dimension
        return result[["share_type", "dimension", "sub_share_type",
                       "count", "weight", "share"]]

    # ------------------------------------------------------------------
    # 1. Prepare analytical views
    # ------------------------------------------------------------------
    df_listings = df_final.copy()
    df_offerings = df_final.explode(["options_str", 
                                     "layer_counts"]).reset_index(drop=False) # transforms each element of a list-like cell into a separate row
    df_offerings.rename(columns={"index": "listing_id"}, inplace=True)

    # ------------------------------------------------------------------
    # 2. Packaging Composition Shares
    # ------------------------------------------------------------------
    comp_off = _weighted_summary(df_offerings, "options_str", "w_offering",
                                 share_type="packaging_composition_share", dimension="offering")
    comp_sal = _weighted_summary(df_offerings, "options_str", "w_sales",
                                 share_type="packaging_composition_share", dimension="sales")

    # ------------------------------------------------------------------
    # 3. Layer Complexity Shares
    # ------------------------------------------------------------------
    df_offerings["layer_class"] = df_offerings["layer_counts"].apply(
    lambda n: (
        "monomaterial structure" if n == 1
        else "two layer laminate structure" if n == 2
        else "multilayer (>2) laminate structure"
    )
)
    lay_off = _weighted_summary(df_offerings, "layer_class", "w_offering",
                                share_type="layer_complexity_share", dimension="offering")
    lay_sal = _weighted_summary(df_offerings, "layer_class", "w_sales",
                                share_type="layer_complexity_share", dimension="sales")

    # ------------------------------------------------------------------
    # 4. Non-Recyclable Presence & Material Breakdown
    # ------------------------------------------------------------------
    ELASTOMERIC = {"PU", "TPU", "EVA", "TPE", "RUBBER", "LATEX", "SILICONE"}
    HALOGENATED = {"PVC", "PVDC"}
    METALLIC    = {"AL", "VMPET", "VMBOPP", "VMBOPET"}
    NONPLASTIC  = {"PAPER", "WOOD", "BAMBOO", "STARCH", "PULP", "COIR", "COTTON",
                   "STRAW", "GLASS", "PLA"}

    def classify_nr(tokens):
        toks = set(t.strip() for t in re.split(r"[+/]", str(tokens).upper()) if t.strip())
        if toks & HALOGENATED:
            return "Halogenated polymer (PVC/PVDC)"
        if toks & ELASTOMERIC:
            return "Crosslinked or elastomeric polymer"
        if (toks & METALLIC) and len(toks) > 1:
            return "Metallized or metallic laminate"
        if (toks & NONPLASTIC) and len(toks) > 1:
            return "Non-plastic or biogenic composite"
        return None

    df_offerings["NR_sub_share_type"] = df_offerings["options_str"].apply(classify_nr)
    df_offerings["nr_flag"] = df_offerings["NR_sub_share_type"].apply(
        lambda x: "contains_non_recyclable_core" if pd.notna(x) else "recyclable"
    )

    total_off_weight = df_offerings["w_offering"].sum()
    total_sal_weight = df_offerings["w_sales"].sum()

    nrflag_off = _weighted_summary(df_offerings, "nr_flag", "w_offering",
                                   total_weight=total_off_weight,
                                   share_type="nr_presence", dimension="offering")
    nrflag_sal = _weighted_summary(df_offerings, "nr_flag", "w_sales",
                                   total_weight=total_sal_weight,
                                   share_type="nr_presence", dimension="sales")

    df_nr_subset = df_offerings[df_offerings["nr_flag"] == "contains_non_recyclable_core"]
    nrcore_off = _weighted_summary(df_nr_subset, "NR_sub_share_type", "w_offering",
                                   share_type="nr_materials", dimension="offering")
    nrcore_sal = _weighted_summary(df_nr_subset, "NR_sub_share_type", "w_sales",
                                   share_type="nr_materials", dimension="sales")

    # ------------------------------------------------------------------
    # 5. Component Presence and Composition
    # ------------------------------------------------------------------
    df_listings["component_flag"] = df_listings["has_component"].map(
        {True: "with_component", False: "no_component"}
    )

    df_listings["component_materials"] = df_listings["material_parsed"].apply(
        lambda x: list(x.get("component_materials", []))
        if isinstance(x, dict) and x.get("component_materials") else []
    )

    df_flat_comp = (
        df_listings[df_listings["component_flag"] == "with_component"]
        .explode("component_materials")
        .dropna(subset=["component_materials"])
        .reset_index(drop=True)
    )

    total_list_weight_off = df_listings["w_offering"].sum()
    total_list_weight_sal = df_listings["w_sales"].sum()

    compflag_off = _weighted_summary(df_listings, "component_flag", "w_offering",
                                     total_weight=total_list_weight_off,
                                     share_type="component_presence", dimension="offering")
    compflag_sal = _weighted_summary(df_listings, "component_flag", "w_sales",
                                     total_weight=total_list_weight_sal,
                                     share_type="component_presence", dimension="sales")

    compmat_off = _weighted_summary(df_flat_comp, "component_materials", "w_offering",
                                    share_type="component_materials", dimension="offering")
    compmat_sal = _weighted_summary(df_flat_comp, "component_materials", "w_sales",
                                    share_type="component_materials", dimension="sales")

    # ------------------------------------------------------------------
    # 6. Component–Body Material Match
    # ------------------------------------------------------------------
    df_match_subset = df_listings[df_listings["has_component"]].copy()
    df_match_subset["component_match_flag"] = df_match_subset["component_match_body"].map(
        {True: "same_material", False: "different_material"}
    )

    match_off = _weighted_summary(df_match_subset, "component_match_flag", "w_offering",
                                  total_weight=df_match_subset["w_offering"].sum(),
                                  share_type="component_match", dimension="offering")
    match_sal = _weighted_summary(df_match_subset, "component_match_flag", "w_sales",
                                  total_weight=df_match_subset["w_sales"].sum(),
                                  share_type="component_match", dimension="sales")

    # ------------------------------------------------------------------
    # 7. Metadata Summary
    # ------------------------------------------------------------------
    n_listings = len(df_listings)
    n_total_offerings = len(df_offerings)
    n_sales_avail = df_offerings[df_offerings["w_sales"] > 0].shape[0]
    n_parsed_off = df_offerings[
        df_offerings["options_str"].notna() &
        (df_offerings["options_str"] != "")
    ].shape[0]

    coverage_info = pd.Series({
        "n_listings": int(n_listings),
        "n_total_offerings": int(n_total_offerings),
        "n_parsed_offerings": int(n_parsed_off),
        "parsed_data_coverage": round(n_parsed_off / n_total_offerings if n_total_offerings else 0, 3),
        "n_sales_available": int(n_sales_avail),
        "sales_data_coverage": round(n_sales_avail / n_total_offerings if n_total_offerings else 0, 3),
        "total_reported_sales": df_offerings["w_sales"].sum(skipna=True)
    })
    df_metadata = coverage_info.to_frame().reset_index().rename(
        columns={"index": "meta_key", 0: "meta_value"}
    )

    # ------------------------------------------------------------------
    # 8. Combine all share tables
    # ------------------------------------------------------------------
    df_shares_flat = pd.concat([
        comp_off, comp_sal,
        lay_off, lay_sal,
        compflag_off, compflag_sal,
        compmat_off, compmat_sal,
        match_off, match_sal,
        nrflag_off, nrflag_sal,
        nrcore_off, nrcore_sal
    ], ignore_index=True)
    
    df_shares_flat.insert(0, "packaging_type", packaging_type) 
    df_metadata.insert(0, "packaging_type", packaging_type)

    # ------------------------------------------------------------------
    # 9. Return unified outputs
    # ------------------------------------------------------------------
    return df_shares_flat, df_listings, df_offerings, df_metadata

df_shares_flat, df_listings, df_offerings, df_metadata = compute_design_shares(
    "./scraped_data_compile/flat_merged_attributes_urls_packaging_chewing_gum_500_20251027_160525.csv")
# %% 7. Batch processing
"""
The output is four lists, all_shares, all_listings, all_offerings, 
all_metadata, with each containing 82 packaging type files
""" 
data_folder = "./scraped_data_compile"
all_files = sorted(glob.glob(os.path.join(data_folder, "flat_merged_attributes_urls_packaging_*.csv")))


all_shares = []
all_listings = []
all_offerings = []
all_metadata = []

os.makedirs("./results", exist_ok=True)

for file_path in all_files:
    print(f"📦 Processing: {os.path.basename(file_path)}")
    try:
        # The function now handles keyword_file_process and packaging_type internally
        df_shares_flat, df_listings, df_offerings, df_metadata = compute_design_shares(file_path)

        # Collect
        all_shares.append(df_shares_flat)
        all_listings.append(df_listings)
        all_offerings.append(df_offerings)
        all_metadata.append(df_metadata)

        # Optional progress summary
        pkg = df_shares_flat["packaging_type"].iloc[0]
        print(f"   ✅ Completed {pkg} ({len(df_offerings)} offerings, {len(df_listings)} listings)")

    except Exception as e:
        print(f"⚠️ Skipped {os.path.basename(file_path)} due to error: {e}")

print(f"\n✅ Finished parsing all {len(all_files)} packaging datasets.\n")

# with open("./results/all_shares.pkl", "wb") as f:
#     pickle.dump(all_shares, f)
# with open("./results/all_listings.pkl", "wb") as f:
#     pickle.dump(all_listings, f)
# with open("./results/all_offerings.pkl", "wb") as f:
#     pickle.dump(all_offerings, f)
# with open("./results/all_metadata.pkl", "wb") as f:
#     pickle.dump(all_metadata, f)

with open("./results/all_shares.pkl", "rb") as f:
    all_shares = pickle.load(f)
with open("./results/all_listings.pkl", "rb") as f:
    all_listings = pickle.load(f)
with open("./results/all_offerings.pkl", "rb") as f:
    all_offerings = pickle.load(f)
with open("./results/all_metadata.pkl", "rb") as f:
    all_metadata = pickle.load(f)
print(f"📊 Loaded {len(all_shares)} share tables from pickle.")
# %% 8. Build extended (cross-packaging) share tables （Table S2, Supplementary Dataset）

# --- Combine all batch outputs into master tables ------------------
df_all_shares    = pd.concat(all_shares, ignore_index=True)
df_all_metadata  = pd.concat(all_metadata, ignore_index=True)
df_all_listings  = pd.concat(all_listings, ignore_index=True)
df_all_offerings = pd.concat(all_offerings, ignore_index=True)

# ------------------------------------------------------------------
def build_extended_share(df_all, share_type, dimension):
    """
    Aggregate a specific share type (e.g. 'packaging_composition_share')
    across all packaging types and normalize per sub_share_type.
    """
    df = df_all.query("share_type == @share_type and dimension == @dimension").copy()
    if df.empty:
        return pd.DataFrame()

    category_col = "sub_share_type"

    # Global total shares
    total = df.groupby(category_col, as_index=False)["weight"].sum()
    total.rename(columns={"weight": "total_weight"}, inplace=True)
    total["total_share"] = total["total_weight"] / total["total_weight"].sum()

    # Distribution across packaging types
    pivot = (
        df.pivot_table(index=category_col,
                       columns="packaging_type",
                       values="weight",
                       aggfunc="sum",
                       fill_value=0)
    )
    pivot_norm = pivot.div(pivot.sum(axis=1), axis=0)

    # Merge & tidy
    df_out = total.merge(pivot_norm, on=category_col, how="left")
    df_out = df_out.sort_values(by="total_share", ascending=False).reset_index(drop=True)
    df_out["share_type"] = share_type
    df_out["dimension"]  = dimension
    return df_out

EXTENDED_SHARE_CONFIG = [
    ("df_ext_comp_off",   "packaging_composition_share", "offering"),
    ("df_ext_comp_sal",   "packaging_composition_share", "sales"),
    ("df_ext_lay_off",    "layer_complexity_share",      "offering"),
    ("df_ext_lay_sal",    "layer_complexity_share",      "sales"),
    ("df_ext_compflag_off", "component_presence",        "offering"),
    ("df_ext_compflag_sal", "component_presence",        "sales"),
    ("df_ext_compmat_off",  "component_materials",       "offering"),
    ("df_ext_compmat_sal",  "component_materials",       "sales"),
    ("df_ext_match_off",    "component_match",           "offering"),
    ("df_ext_match_sal",    "component_match",           "sales"),
    ("df_ext_nrflag_off",   "nr_presence",               "offering"),
    ("df_ext_nrflag_sal",   "nr_presence",               "sales"),
    ("df_ext_nrcore_off",   "nr_materials",              "offering"),
    ("df_ext_nrcore_sal",   "nr_materials",              "sales"),
]

extended_share_results = {}
for varname, share_type, dimension in EXTENDED_SHARE_CONFIG:
    extended_share_results[varname] = build_extended_share(df_all_shares, share_type, dimension)
 

def extract_top_packagings(df_ext, top_n_rows=10, top_n_cols=5):
    """
    Extract top-N sub_share_types (rows) and their top-N packaging types (columns)
    by global total weight share.
    """
    if df_ext.empty:
        return pd.DataFrame()

    top_df = df_ext.sort_values("total_share", ascending=False).head(top_n_rows)
    rows_out = []

    for _, row in top_df.iterrows():
        combo = row["sub_share_type"]
        total_share = row["total_share"]

        # Pick packaging-type columns (skip metadata columns)
        pack_cols = [c for c in row.index if c not in 
                     ["sub_share_type", "total_weight", "total_share", "share_type", "dimension"]]
        pack_shares = row[pack_cols].sort_values(ascending=False).head(top_n_cols)

        top_pack = [f"{p} ({s:.2%})" for p, s in pack_shares.items()]
        while len(top_pack) < top_n_cols:
            top_pack.append("")

        rows_out.append([combo, total_share] + top_pack)

    columns = ["sub_share_type", "total_share"] + [f"top{i+1}" for i in range(top_n_cols)]
    return pd.DataFrame(rows_out, columns=columns)


TOP_N_ROWS = 10
TOP_N_COLS = 5

top_results = {}
for name, df_ext in extended_share_results.items():
    top_results[f"{name}_top{TOP_N_ROWS}"] = extract_top_packagings(
        df_ext,
        top_n_rows=TOP_N_ROWS,
        top_n_cols=TOP_N_COLS
    )
    
## Generating Supplementary Dataset: extended_share_results.xlsx
with pd.ExcelWriter("./results/extended_share_results.xlsx") as writer:
    for name, df in extended_share_results.items():
        df.to_excel(writer, sheet_name=name[:31], index=False)

        
# Extract packaging keyword names in canonical order
packaging_sheet_names = [
    str(df['packaging_type'].iloc[0])[:31]
    for df in all_shares
]

with pd.ExcelWriter('./results/all_shares_per_keyword.xlsx') as writer:
    for sheet_name, df in zip(packaging_sheet_names, all_shares):
        df.to_excel(writer, sheet_name=sheet_name, index=False)   
        
os.makedirs("./results/all_listings", exist_ok=True)
for sheet_name, df in zip(packaging_sheet_names, all_listings):
    out = f"./results/all_listings/listings_{sheet_name}.csv"
    df.to_csv(out, index=False, encoding="utf-8")

os.makedirs("./results/all_offerings", exist_ok=True)
for sheet_name, df in zip(packaging_sheet_names, all_offerings):
    out = f"./results/all_offerings/offerings_{sheet_name}.csv"
    df.to_csv(out, index=False, encoding="utf-8")
    
os.makedirs("./results/all_metadata", exist_ok=True)
for sheet_name, df in zip(packaging_sheet_names, all_metadata):
    out = f"./results/all_metadata/metadata_{sheet_name}.csv"
    df.to_csv(out, index=False, encoding="utf-8")