"""
Purpose:
This script collects product-listing URLs from Alibaba.com search results
for food-packaging formats associated with standardized packaging keywords.

Method:
- Takes as input a packaging keyword and an associated Alibaba category ID
  (e.g. Packaging & Printing) to constrain searches to relevant product types.
- Uses Selenium with a persistent Firefox browser profile to simulate
  human browsing behavior and paginate through search-result pages.
- Extracts unique product-detail URLs along with basic metadata,
  including listing title, page number, and highlighted keyword terms.
- Applies deduplication logic to avoid repeated URLs across pages.

Outputs:
- A structured, timestamped CSV file containing collected product URLs
  and associated metadata.
- This file serves as the direct input for subsequent attribute extraction
  and material-parsing steps.

Context:
This script represents the URL-collection stage of the data-acquisition
pipeline. It links keyword mapping to detailed listing-level data and
enables reproducible retrieval of packaging-design listings from a
global B2B marketplace.

Author:
Kai Li, Chair of Operations Management, RWTH Aachen University

Contact:
k.li@om.rwth-aachen.de
"""
# %%
import csv, random, time
from time import perf_counter
from pathlib import Path
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.firefox import GeckoDriverManager

# ============ CONFIG ============
KEYWORD    = "packaging preserved fruit"
CATEGORYID = 23
NEED_N     = 500
HEADLESS   = False
WAIT_SEC   = 30
PAGE_PAUSE = (0.4, 1)
RUN_TS     = datetime.now().strftime("%Y%m%d_%H%M%S")
KEYWORD_CLEAN = KEYWORD.replace(" ", "_")
OUT_FILE = f"./scraped_data/urls_{KEYWORD_CLEAN}_{NEED_N}_{RUN_TS}.csv"
PROFILE_DIR = (r"C:\Users\laptop-kl\AppData\Roaming\Mozilla\Firefox\Profiles"
               r"\3bui4ugu.alibabascrape")
SEARCH_ANCHORS = (
    "h2.search-card-e-title a[href*='/product-detail/']")
# =================================

def firefox_driver(headless=False):
    """Create Firefox driver using the real profile (cookies persist)."""
    opts = Options()
    if headless:
        opts.add_argument("--headless")
        opts.add_argument("--width=1280")
        opts.add_argument("--height=900")
    opts.page_load_strategy = "eager"

    # Use the real profile in-place
    opts.add_argument("-profile")
    opts.add_argument(str(Path(PROFILE_DIR)))

    driver = webdriver.Firefox(
        service=Service(GeckoDriverManager().install()),
        options=opts
    )
    if not headless:
        driver.set_window_size(1280, 900)
    print("Active profile:", driver.capabilities.get("moz:profile"))
    return driver

def collect_product_urls(driver, base_url, need_n):
    rows, seen = [], set()
    page = 1
    while len(rows) < need_n:
        url = base_url if page == 1 else f"{base_url}&page={page}"
        driver.get(url)
        driver.execute_script("window.scrollBy(0, 300);")
        try:
            WebDriverWait(driver, WAIT_SEC, poll_frequency=0.25).until(
              EC.presence_of_element_located((By.CSS_SELECTOR, SEARCH_ANCHORS))
            )
        except:
            break
        anchors = driver.find_elements(By.CSS_SELECTOR, SEARCH_ANCHORS) # return every a element whose href contains /product-detail/, and that is a descendant of an h2.search-card-e-title
        new_rows = 0
        for a in anchors:
            href = (a.get_attribute("href") or "").strip()
            if not href or href in seen:
                continue
                
            # title from first <span> if present, else anchor text
            try:
                span = a.find_element(By.TAG_NAME, "span")
                title_text = (span.text or "").strip()
            except Exception:
                title_text = (a.text or "").strip()
            title_text = " ".join(title_text.split())
            
            # collect highlighted tokens from <strong> (fallback <b>)
            # highlighted tokens from <strong>/<b>
            hi_tokens = set()
            try:
                for tag in ("strong", "b"):
                    for s in a.find_elements(By.TAG_NAME, tag):
                        t = (s.text or "").strip().lower()
                        if t:
                            hi_tokens.add(t)
            except Exception:
                pass
            
            seen.add(href)
            rows.append({
                "page": page,
                "url": href,
                "title": title_text,
                "highlighted_tokens": "|".join(sorted(hi_tokens)),
                "highlight_count": len(hi_tokens),
            })
            new_rows += 1
            if len(rows) >= need_n:
                break
            
        print(f"Page {page}: +{new_rows} (total {len(rows)})")
        if new_rows == 0:
            break
        page += 1
        #time.sleep(random.uniform(*PAGE_PAUSE))
    return rows[:need_n]

if __name__ == "__main__":
    search_url = (
        f"https://www.alibaba.com/trade/search?"
        f"fsb=y&IndexArea=product_en&categoryId={CATEGORYID}&SearchText={KEYWORD}"
    )
    driver = firefox_driver(HEADLESS)
    urls = collect_product_urls(driver, search_url, NEED_N)
    driver.quit()

    fetch_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(OUT_FILE, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        #w.writerow(["count", "url", "url_colleting_time"])  
        w.writerow(["count","page","url","title","highlighted_tokens","highlight_count","url_collecting_time"])                                 # three columns added
        for i, r in enumerate(urls, 1):  # 'urls' is now the list of dict rows
            w.writerow([i, r["page"], r["url"], r["title"], r["highlighted_tokens"], r["highlight_count"], fetch_time])

    print(f"\n✅ Saved {len(urls)} URLs to {OUT_FILE} at {fetch_time}")