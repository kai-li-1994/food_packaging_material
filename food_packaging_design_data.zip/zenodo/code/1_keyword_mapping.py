"""
Purpose:
This script implements a rule-based text-parsing and classification workflow
that maps EU Combined Nomenclature (CN 2025) food-product descriptions
(CN Chapters 02–23) to standardized packaging keywords.

These packaging keywords represent typical food-packaging formats
(e.g. "packaging frozen fish", "packaging coffee beans",
"packaging liquid milk") and serve as structured search inputs for
automated data retrieval from the Alibaba.com B2B marketplace.

Method:
- Cleans CN product descriptions by removing negations and exclusion clauses
  (e.g. “excluding”, “not”, “whether or not”) to prevent false keyword matches.
- Applies chapter-specific regular-expression rules to identify product state,
  form, and type (e.g. fresh/frozen/dried; liquid/powder; meat/fish/vegetable).
- Uses a transparent rule engine to assign each CN code to a single,
  standardized packaging keyword.
- Generates documentation tables reporting regex patterns, mapping logic,
  and the number of CN codes mapped to each keyword.

Outputs:
- A CN-to-packaging-keyword mapping table used for downstream web scraping.
- Supplementary tables (Table S1) documenting all regex rules and mappings,
  supporting transparency and reproducibility.

Context:
This script provides the conceptual bridge between trade classifications
(CN codes) and packaging-design evidence, enabling design-level material
analysis of food packaging in global B2B supply chains.

Author:
Kai Li, Chair of Operations Management, RWTH Aachen University

Contact:
k.li@om.rwth-aachen.de
"""
import pandas as pd
import re
# %% 1. Negation cleaning
EXCL_WORDS = r'(?:excl\.|excluding|except|other than|otherwise than)'
NEG_ANY_PAREN = re.compile(rf'\([^)]*{EXCL_WORDS}[^)]*\)', re.I)
NEG_INLINE   = re.compile(rf'\b{EXCL_WORDS}\b[^;.()]*?(?=[;.()]|$)', re.I)
#NOT_SPAN     = re.compile(r'\bnot\b[^,;.()]*?(?=[,;.()]|$)', re.I)
#NOT_SPAN = re.compile(r'\bnot\b[^;.)]*(?:or\s+\w+)*', re.I)
NOT_SPAN = re.compile(
    r'\bnot\b(?![^;.)]*\bfor\s+technical\s+or\s+industrial\s+uses\b)[^;.)]*(?:or\s+\w+)*',
    re.I
)
WHETHER_BLOCK= re.compile(r'\bwhether or not\b[^,;.()]*?(?=[,;.()]|$)', re.I)

def clean_negations(text: str) -> str:
    s = (text or "").lower()
    s = NEG_ANY_PAREN.sub(' ', s)
    s = NEG_INLINE.sub(' ', s)
    s = WHETHER_BLOCK.sub(' ', s)
    s = NOT_SPAN.sub(' ', s)
    return s
# %% 2. Regex and rule dictionaries CN02–CN23
# %%% CN02&CN03
FRESH = re.compile(r'\b(fresh|chilled|refrigerated|compensated)\b', re.I)
FROZEN    = re.compile(r'\bfrozen\b', re.I)
PROCESSED = re.compile(r'\b(salted|dried|smoked|in brine|prepared|cooked|preserved|cured|edible\s+(flours?|meals?))\b', re.I)
LIVE      = re.compile(r'\blive\b', re.I)

RULES_CN02 = {
    "CN Chapter": "02 (Meat)",
    "patterns": {"fresh": FRESH, "frozen": FROZEN, "processed": PROCESSED},
    "mapping_rules": [
        ("processed", "packaging processed meat"),
        ("frozen and not fresh", "packaging frozen meat"),
        ("fresh and not frozen", "packaging fresh meat"),
        #("fresh and frozen", "packaging fresh frozen meat"),
        ("Others", "packaging fresh frozen meat"),   # fallback
    ]
}

RULES_CN03 = {
    "CN Chapter": "03 (Fish & seafood)",
    "patterns": {"live": LIVE, "fresh": FRESH, "frozen": FROZEN},
    "mapping_rules": [
        ("live and not (fresh or frozen)", "packaging live fish"),
        ("fresh and not (frozen or live)", "packaging fresh fish seafood"),
        ("frozen and not (fresh or live)", "packaging frozen fish seafood"),
        ("Others", "packaging fish seafood"),
    ]
}
# %%% CN04
SOLID   = re.compile(r'\b(powder|granule(?:s)?|solid form(?:s)?)\b', re.I)
CONC    = re.compile(r'\b(concentrated|condensed|evaporated)\b', re.I)
YOGURT  = re.compile(r'\b(yogurt|yoghurt)\b', re.I)
WHEY    = re.compile(r'\bwhey\b(?!\s+(cheese|curd|butter))', re.I)
CHEESE  = re.compile(
    r'\b(cheese|mozzarella|gorgonzola|roquefort|emment(?:al|aler)|(gruyère|gruyere)|sbrinz|'
    r'bergkäse|appenzell|cheddar|edam|tilsit|kashkaval|feta|'
    r'fiore sardo|pecorino|provolone|maasdam|asiago|caciocavallo|montasio|ragusano|'
    r'danbo|fontal|fontina|fynbo|havarti|maribo|(samso|samsø)|gouda|esrom|italico|kernhem|'
    r'saint[-\s]?nectaire|saint[-\s]?paulin|taleggio|cantal|cheshire|wensleydale|lancashire|'
    r'double\s+gloucester|blarney|colby|monterey|camembert|brie|'
    r'kefalotyri|kefalograviera|kasseri|grana padano|parmigiano reggiano|'
    r'fromage fribourgeois|vacherin\s+mont\s+(d’or|dor)|(tête de moine|tete de moine)|kefalo[-\s]?tyri|finlandia|jarlsberg)\b',
    re.I)
BUTTER  = re.compile(r'\bbutter\b|fats\s+and\s+oils.*>\s*=\s*99,3\s*%', re.I)
SPREADS = re.compile(r'\bdairy spread(?:s)?\b', re.I)
MILK    = re.compile(r'\bmilk\b(?!\s+(cheese|powder|chocolate|curd|dessert|ice cream))', re.I)
CREAM   = re.compile(r'\bcream\b', re.I)
HONEY   = re.compile(r'\bhoney\b', re.I)
INSECTS = re.compile(r'\binsect(?:s)?\b', re.I)
EGG     = re.compile(r'\b(?:egg(?:s)?|egg yolk(?:s)?)\b', re.I)

RULES_CN04 = {
    "CN Chapter": "04 (Dairy, eggs, honey)",
    "patterns": {"milk": MILK, "cream": CREAM, "solid": SOLID, 
                 "concentrated": CONC,"yogurt": YOGURT, "whey": WHEY, 
                 "cheese": CHEESE, "butter": BUTTER, "spreads": SPREADS, 
                 "honey": HONEY, "egg": EGG, "insects": INSECTS},
    "mapping_rules": [
        ("honey", "packaging honey"),
        ("egg", "packaging egg"),
        ("whey", "packaging whey"),
        ("yogurt", "packaging yogurt"),
        ("butter", "packaging food butter"),
        ("(milk or cream) and solid", "packaging milk powder"),
        ("(milk or cream) and concentrated", "packaging condensed milk"),
        ("milk or cream", "packaging liquid milk"),
        ("spreads", "packaging dairy spreads"),
        ("cheese", "packaging cheese"),
        ("insects", "packaging fresh frozen meat"),  # consistent with your earlier mapping
    ]
}
# %%% CN07
DRIED = re.compile(r'\b(dried|dehydrated|desiccated|currants?|sultanas?)\b', re.I)
POTATO_ONION_GARLIC = re.compile(r'\b(potato(?:es)?|onion(?:s)?|garlic|shallot(?:s)?)\b', re.I)
LEAFY_VEGETABLES = re.compile(
    r'\b('
    r'lettuce(?:s)?|cabbage(?:s)?|kale(?:s)?|chicor(?:y|ies)|'
    r'spinach(?:es)?|witloof|endive(?:s)?|brussels\s+sprout(?:s)?|'
    r'brassica(?:s)?|chard(?:s)?|fennel|cardoon(?:s)?|'
    r'leek(?:s)?|celery(?!\s*(root|celeriac))|'
    r'artichoke(?:s)?|salad(?:s)?(?!\s+beetroot)'
    r')\b',
    re.I
)
MUSHROOM = re.compile(
    r'\b(mushroom(?:s)?|truffle(?:s)?|agaricus|boletus|cantharellus|shiitake|'
    r'matsutake|tuber|fungi|auricularia|tremella)\b',
    re.I
)

RULES_CN07 = {
    "CN Chapter": "07 (Vegetables)",
    "patterns": {"dried": DRIED, "fresh": FRESH, "frozen": FROZEN, 
                 "mushroom": MUSHROOM, "root": POTATO_ONION_GARLIC, 
                 "leafy": LEAFY_VEGETABLES},
    "mapping_rules": [
        ("frozen and not fresh and not dried", "packaging frozen vegetables"),
        ("root", "packaging potato onion garlic"),
        ("leafy", "packaging leafy vegetables"),
        ("mushroom", "packaging mushroom tray"),
        ("Others", "packaging vegetables"),
    ]
}
# %%% CN08
NUTS = re.compile(
    r'\b('
    r'almonds?|'
    r'areca\s+nuts?|'
    r'brazil\s+nuts?|'
    r'betel\s+nuts?|'
    r'cashews?(?!\s+apple(?:s)?)|'
    r'chestnuts?|'
    r'coconuts?|'
    r'filberts?|'
    r'groundnuts?|'
    r'hazelnuts?|'
    r'(?:kola|cola)\s*nuts?|'
    r'macadamias?|'
    r'nuts?|'
    r'pecans?|'
    r'pine\s+nuts?|'
    r'pistachios?|'
    r'walnuts?'
    r')\b',
    re.I
)
FRUIT = re.compile(
    r'\b('
    r'apples?|apricots?|avocados?|bananas?|blackberries?|blackcurrants?|'
    r'blueberries?|carambola|cashew\s*apples?|cherries?|clementines?|'
    r'cowberries?|cranberries?|currants?|dates?|durians?|'
    r'figs?|foxberries?|fruit(?:s)?|ginger|'
    r'gooseberries?|grapefruits?|grapes?|guavas?|jackfruit|kiwifruit|'
    r'lemons?|limes?|loganberries?|lychees?|mandarins?|mango(?:es|steens)?|'
    r'melons?|mulberries?|nectarines?|oranges?|papaya(?:s)?|papaws?|pawpaws?|'
    r'passion\s*fruit|peaches?|pears?|persimmons?|pineapples?|pitahaya|pitaya|'
    r'plátano\s+de\s+canarias|plantains?|plums?|pomegranates?|pomelos?|'
    r'prunes?|quinces?|redcurrants?|raisins?|raspberries?|'
    r'sapodillo\s*plums?|satsumas?|sloes?|strawberries?|sultanas?|tamarinds?|'
    r'tangerines?|vaccinium|watermelons?|wilkings?'
    r')\b',
    re.I
)

RULES_CN08 = {
    "CN Chapter": "08 (Fruit & nuts)",
    "patterns": {"dried": DRIED, "fresh": FRESH, "frozen": FROZEN, 
                 "nuts": NUTS, "fruit": FRUIT},
    "mapping_rules": [
        ("fruit and nuts", "packaging fruit nuts"),
        ("nuts and not fruit", "packaging nuts"),
        ("fruit and fresh and frozen and dried", "packaging fruit"),
        ("fruit and frozen and not nuts", "packaging frozen fruit"),
        ("fruit and fresh and not dried and not frozen and not nuts", "packaging fresh fruit"),
        ("fruit and dried and not fresh and not frozen and not nuts", "packaging dried fruit"),
        ("Others", "packaging fruit"),
    ],
}
# %%% CN09
COFFEE   = re.compile(r'\b(coffee|chicory|coffee\s*substitutes?)\b', re.I)  # chicory & substitutes → instant coffee side
TEA_MATE = re.compile(r'\b(tea|mate)\b', re.I)
SPICES = re.compile(
    r'\b('
    r'pepper(?:s)?|capsicum|pimenta|vanilla|cinnamon|clove(?:s)?|nutmeg|mace|cardamom(?:s)?|'
    r'coriander|cumin|fennel|caraway|anise|badian|juniper|ginger|saffron|turmeric|'
    r'fenugreek|bay leaves?|thyme|curry|spices?|spice mix(?:ture|tures|es)?)\b',
    re.I
)

RULES_CN09 = {
    "CN Chapter": "09 (Coffee, tea, spices)",
    "patterns": {"coffee": COFFEE, "tea": TEA_MATE, "spices": SPICES},
    "mapping_rules": [
        ("coffee", "packaging coffee beans"),
        ("tea", "packaging tea leaves"),
        ("spices", "packaging spices"),
    ]
}
# %%% CN10
#FOR_SOWING = re.compile(r'\bseed(?:s)?\s+for\s+sowing\b|\bfor\s+sowing\b', re.I)
FOR_SOWING = re.compile(r'\bfor sowing\b', re.I)
RICE_WORDS = re.compile(
    r'\b(rice|parboiled|husk(?:ed|ing)?|semi[-\s]?milled|wholly[-\s]?milled|broken)\b',
    re.I)

RULES_CN10 = {
    "CN Chapter": "10 (Cereals)",
    "patterns": {"sowing": FOR_SOWING, "rice": RICE_WORDS},
    "mapping_rules": [
        ("sowing", "packaging seeds"),
        ("rice", "packaging rice"),
        ("Others", "packaging grain"),
    ]
}
# %%% CN11
# no regex since all products are mapped to 'packaging flour'
RULES_CN11 = {
    "CN Chapter": "11 (Products of milling industry)",
    "patterns": {},
    "mapping_rules": [("Others", "packaging flour")]
}
# %%% CN12
FLOUR_MEAL  = re.compile(r'\b(flour|meal)\b', re.I)
SEAWEED     = re.compile(r'\b(seaweed|algae)\b', re.I)
BOTANICALS  = re.compile(
    r'\b(hops?|lupulin|ginseng|coca(?:\s+leaf)?|poppy\s+straw|ephedra|tonquin\s+beans?|'
    r'bark(?:\s+of\s+african\s+cherry)?|perfumery|pharmacy|medicinal|'
    r'insecticidal|fungicidal|plants?\s+and\s+parts?)\b',
    re.I
)
FORAGE = re.compile(
    r'\b(straw|husks?|hay|lucerne|alfalfa|clover|sainfoin|forage|kale|'
    r'lupines?|vetch(?:es)?|swedes?|mangolds?|fodder\s+roots?)\b',
    re.I
)
OILSEED = re.compile(
    r'\b(soya|soybeans?|groundnuts?|peanuts?|copra|linseed|flaxseed|locust\s+bean\s+seeds?|'
    r'(?:rape|colza|rapeseed)(?:\s+seeds?)?|sunflower(?:\s+seeds?)?|'
    r'palm\s+(?:nuts?|kernels?)|cotton\s+seeds?|castor(?:\s+oil)?\s+seeds?|'
    r'sesam(?:e|um)(?:\s+seeds?)?|mustard\s+seeds?|safflower(?:\s+seeds?)?|'
    r'melon\s+seeds?|poppy\s+seeds?|hemp\s+seeds?|oleaginous|oil\s+seeds?)\b',
    re.I
)
VEG_LIKE = re.compile(
    r'\b(sugar\s+beet|sugar\s+cane|chicory\s+roots?|locust\s+beans?|vegetable)\b',
    re.I
)
RULES_CN12 = {
    "CN Chapter": "12 (Oil seeds, oleaginous fruits, fodder)",
    "patterns": {"flour": FLOUR_MEAL, "seaweed": SEAWEED, "botanicals": BOTANICALS,
                 "forage": FORAGE, "sowing": FOR_SOWING, "oilseed": OILSEED, 
                 "vegetable_related": VEG_LIKE},
    "mapping_rules": [
        ("flour and oilseed", "packaging flour"),
        ("botanicals", "packaging spices"),
        ("forage and not sowing", "packaging forage"),
        ("sowing or oilseed", "packaging seeds"),
        ("seaweed or vegetable_related", "packaging vegetables"),
    ]
}
# %%% CN15
OIL_INDUSTRY = re.compile(
    r'\b(glycerol(?:\s+waters|\s+lyes)?|degras|soapstocks?|oil\s+foots?|dregs|'
    r'residues?|linoxyn|for\s+(?:technical|industrial)(?:\s+or\s+(?:technical|industrial))?\s+uses?)\b',
    re.I
)
WAXES = re.compile(
    r'\b(beeswax|insect\s+waxes?|spermaceti|vegetable\s+waxes?|japan\s+wax|' 
    r'myrtle\s+wax|wax(?:es)?)\b',
    re.I
)
MARGARINE = re.compile(
    r'\bmargarine\b|\bedible(?:\s+(?:mixtures?|preparations?))?\b|'
    r'\bmixtures?\s+or\s+preparations?\b',
    re.I
)
ANIMAL_OIL = re.compile(
    r'\b(lard|pig|poultry|tallow|bovine|cattle|cow|ox|sheep|goat|animal|'
    r'marine\s+mammal|fish(?:-liver)?|wool\s+grease|lanolin)\b',
    re.I
)
VEG_OIL = re.compile(
    r'\b(soy|soya|soybean|groundnut|peanut|olives?|palm(?:\s+kernel)?|sunflower|'
    r'safflower|cotton-?seed|coconut|babassu|rape|colza|rapeseed|mustard|'
    r'linseed|flaxseed|maize|corn\s+oil|castor|sesame|microbial|'
    r'tobacco[-\s]?seed|tung|jojoba|oiticica|vegetable)\b',
    re.I
)
RULES_CN15 = {
    "CN Chapter": "15 (Fats & oils)",
    "patterns": {"industrial": OIL_INDUSTRY, "wax": WAXES,
                 "margarine": MARGARINE, "animal_oil": ANIMAL_OIL, "vegetable_oil": VEG_OIL},
    "mapping_rules": [
        ("industrial", "packaging oil industrial use"),
        ("wax", "packaging wax"),
        ("margarine", "packaging margarine"),
        ("animal_oil", "packaging animal oil"),
        ("vegetable_oil", "packaging vegetable oil"),
    ]
}
# %%% CN16
SAUSAGE = re.compile(r'\bsausages?\b', re.I)
CAVIAR  = re.compile(r'\bcaviar\s+(?:substitutes?)?\b', re.I)

RULES_CN16 = {
    "CN Chapter": "16 (Meat/fish prep)",
    "patterns": {"sausage": SAUSAGE, "caviar": CAVIAR},
    "mapping_rules": [
        ("sausage", "packaging sausage"),
        ("caviar", "packaging caviar"),
        ("Others", "packaging canned meat"),
    ]
}
# %%% CN17
CHEWING_GUM = re.compile(r'\bchewing\s+gum\b', re.I)
WHITE_CHOC  = re.compile(r'\bwhite\s+chocolate\b', re.I)
CANDY_WORDS = re.compile(
    r'\b('
    r'confectionery|pastilles?|cough\s+drops|panned|gum\s+and\s+jelly|jelly\s+confectionery|'
    r'boiled\s+sweets?|toffees?|caramels?|marzipan|nougat|pastes?|compressed\s+tablets?'
    r')\b', re.I
)
SUGAR = re.compile(
    r'\b((beet|cane|white|maple)\s+sugar|'   # e.g. "raw cane sugar", "white sugar"
    r'sucrose|lactose|glucose|dextrose|fructose|isoglucose|maltose|maltodextrin(?:e)?|'  # pure sugar names
    r'(solid|powder)\s+form'                         # “solid form”, “powder form”
    r')\b',
    re.IGNORECASE | re.UNICODE
)
SYRUP = re.compile(
    r'\b(syrups?|molasses)\b',
    re.IGNORECASE | re.UNICODE
)

RULES_CN17 = {
    "CN Chapter": "17 (Sugars & confectionery)",
    "patterns": {"gum": CHEWING_GUM, "whitechoc": WHITE_CHOC,
                 "candy": CANDY_WORDS, "sugar": SUGAR, "syrup": SYRUP},
    "mapping_rules": [
        ("gum", "packaging chewing gum"),
        ("whitechoc", "packaging chocolate"),
        ("candy", "packaging candy"),
        ("sugar", "packaging sugar"),
        ("syrup", "packaging syrup"), 
     
    ]
}
# %%% CN18
COCOA_INTER = re.compile(r'\bcocoa\b', re.I)
CHOCOLATE   = re.compile(r'\b(chocolates?)\b', re.I)

RULES_CN18 = {
    "CN Chapter": "18 (Cocoa & chocolate)",
    "patterns": {"chocolate": CHOCOLATE, "cocoa": COCOA_INTER},
    "mapping_rules": [
        ("chocolate", "packaging chocolate"),
        ("cocoa", "packaging cocoa"),
    ]
}
# %%% CN19
INFANT = re.compile( r'\binfant\b',re.I)
FLOUR_LIKE= re.compile(
    r'\b(malt\s+extract|tapioca|in\s+powder\s+form)\b', re.I
)
PASTA       = re.compile(r'\b(pasta|couscous)\b', re.I)
BISCUITS    = re.compile(r'\b(biscuit(?:s)?|cookies?|wafer(?:s)?|rusks?'
                         r'|crispbread|crackers?|matzos?|'
                         r'extruded\s+or\s+expanded\s+products?)\b', re.I)
BREAD       = re.compile(r'\b(bread|toasted\s+bread|toast)\b', re.I)
CAKES       = re.compile(
    r'\b(gingerbread|cake(?:s)?|tarts?|marzipan|meringues?|stollen|'
    r'croissant(?:s)?|pastry|pastries)\b', re.I
)
PIZZA_QUICHE    = re.compile(r'\b(pizza(?:s)?|quiches?)\b', re.I)
CEREALS   = re.compile(r'\b(cereals?|bulgur\s+wheat)\b', re.I)

RULES_CN19 = {
    "CN Chapter": "19 (Cereal preparations, bakery)",
    "patterns": {"infant": INFANT, "floury": FLOUR_LIKE, 
                 "pasta": PASTA, "biscuits": BISCUITS, "bread": BREAD,
                 "cakes": CAKES, "pizza":PIZZA_QUICHE, "cereal":CEREALS, "rice": RICE_WORDS},
    "mapping_rules": [
        ("pizza", "packaging pizza"),
        ("pasta", "packaging pasta"),
        ("biscuits", "packaging biscuits"),
        ("cakes", "packaging cakes pastries"),
        ("bread", "packaging bread"),
        ("infant", "packaging baby food"),
        ("floury", "packaging flour"),
        ("cereal", "packaging cereal"),
        ("rice", "packaging rice"),
    ]
}
# %%% CN20 
PICKLED = re.compile(
    r'\bvinegar\b|\bacetic\s+acid\b|\b(pickle|pickled)\b|\bsauerkraut\b|by\s+vinegar\s+or\s+acetic\s+acid',
    re.I
)
JAM     = re.compile(r'\b(jams?|jell(?:y|ies)|marmalades?|pur(?:ee|ees|ée|ées))\b', re.I)
JUICE   = re.compile(r'\b(juices?|nectar)\b', re.I)
PEATNUT_BUTTER =re.compile(r'\b(peanut\s+butter)\b', re.I)
VEG = re.compile(
    r'\b('
    r'vegetables?|tomatoes?|mushrooms?|truffles?|potatoes?|sweet\s*corn|sweetcorn|corn|peas?|beans?|'
    r'asparagus|olives?|bamboo\s+shoots?|artichokes?|capers?|onions?|palm\s*hearts?'
    r')\b', re.I)

RULES_CN20 = {
    "CN Chapter": "20 (Veg/fruit preparations, juice)",
    "patterns": {"pickled": PICKLED, "jam": JAM, "juice": JUICE, "nuts": NUTS, "peanut_butter":PEATNUT_BUTTER, "vegetable": VEG, "fruit": FRUIT},
    "mapping_rules": [
        ("jam", "packaging jam"),
        ("pickled", "packaging pickles"),
        ("juice", "packaging juice"),
        ("peanut_butter", "packaging peanut butter"),
        ("vegetable", "packaging canned vegetable"),
        ("fruit and nuts", "packaging preserved fruit nuts"),
        ("fruit and not nuts", "packaging preserved fruit"),
        ("nuts and not fruit", "packaging nuts"),
    ]
}
# %%% CN21
YEAST_BAKING = re.compile(
    r'\b(yeasts?|baking\s*powders?|baking\s*soda|sodium\s*bicarbonate|leavening\s*agents?|single-cell|micro[-\s]?organisms?)\b',
    re.I
)
SAUCE_WORDS  = re.compile(r'\b(sauces?|ketchup|mustard|chutney|condiment|seasoning|bitters)\b', re.I)
SOUP_WORDS   = re.compile(r'\b(soups?|broths?)\b', re.I)
ICE_CREAM    = re.compile(r'\b(ice\s*cream|edible\s*ice)\b', re.I)
#SYRUP_WORDS  = re.compile(r'\b(syrups?|alcoholic\s+preparations?)\b', re.I)
PROTEIN = re.compile(
    r'\b(protein\s*concentrates?|textured\s*protein)\b',
    re.I
)

RULES_CN21 = {
    "CN Chapter": "21 (Misc. food preparations)",
    "patterns": {"infant": INFANT, "coffee": COFFEE, "tea": TEA_MATE,
                 "yeast": YEAST_BAKING, "sauce": SAUCE_WORDS, "soup": SOUP_WORDS,
                 "icecream": ICE_CREAM, "syrup": SYRUP, "protein": PROTEIN},
    "mapping_rules": [
        ("infant", "packaging baby food"),
        ("coffee", "packaging instant coffee"),
        ("tea", "packaging instant tea"),
        ("yeast", "packaging yeast powder"),
        ("sauce", "packaging sauce"),
        ("soup", "packaging soup"),
        ("icecream", "packaging ice cream"),
        ("syrup", "packaging syrup"),
        ("protein", "packaging protein"),
    ]
}
# %%% CN22
WATER = re.compile(
    r'\b(water|waters?|spring\s+water|mineral\s+water|aerated\s+water|carbonated\s+water|ice|snow)\b',
    re.I
)
SOFT_DRINK = re.compile(
    r'\b(beverage(?:s)?|drink(?:s)?|soft\s+drink|carbonated|soda|sparkling\s+(?:beverage|drink)|energy\s+drink|non[-\s]?alcoholic)\b',
    re.I
)
PLANT_MILK = re.compile(
    r'\b(soya|soy(?:a)?|soybean|soymilk|plant[-\s]?based|oat|almond|rice\s+milk|coconut|hazelnut|cashew|nut[-\s]?based|vegetable\s+milk|non[-\s]?dairy)\b',
    re.I
)
BEER = re.compile(
    r'\b(beer|malt\s+beer|lager|ale|stout|porter|non[-\s]?alcoholic\s+beer|cider|perry|mead|piquette)\b',
    re.I
)
WINE = re.compile(
    r'\b(wines?(?!\s+vinegar)|sparkling\s+wines?|champagne|prosecco|cava|vermouth|'
    r'grape\s+must|fortified\s+wine|port|sherry|marsala|tokaj|asti|madeira|'
    r'muscatel|samos|muscat\s+de\s+Lemnos)\b',
    re.I
)
SPIRIT = re.compile(
    r'\bspirit(?:s|uous)?\b|\balcoholic\s+beverage\b|\bliquor\b|\bwhisky\b|\bwhiskey\b|\brum\b|'
    r'\bvodka\b|\bgin\b|\bbrandy\b|\bcognac\b|\barmagnac\b|\bgrappa\b|\btequila\b|\bouzo\b|\barrack\b|\bgeneva\b|'
    r'\bliqueurs?\b|\bcordials?\b|\bcalvados\b|undenatured\s+ethyl\s+alcohol.*<\s*80\s*%',
    re.I
)

VINEGAR = re.compile(r'\b(vinegar|acetic\s+acid)\b', re.I)
AlCOHOL_INDUSTRY = re.compile(
    r'undenatured\s+ethyl\s+alcohol.*>=\s*80\s*%|\bdenatured\s+ethyl\s+alcohol\b',
    re.I
)

RULES_CN22 = {
    "CN Chapter": "22 (Beverages, spirits & vinegar)",
    "patterns": {
        "water": WATER, "softdrink": SOFT_DRINK, 
        "beer": BEER, "wine": WINE, "spirit": SPIRIT, "vinegar": VINEGAR, "industrial": AlCOHOL_INDUSTRY },
    "mapping_rules": [
        ("industrial", "packaging industrial alcohol"),
        ("spirit", "packaging alcoholic spirit"),
        ("wine", "packaging wine"),
        ("water", "packaging water"),
        ("beer", "packaging beer"),
        ("vinegar", "packaging vinegar"),
        ("softdrink", "packaging soft drink"),
    ],
}
# %%% CN23
PET_FEED = re.compile(r'\b(dog|cat)\b',re.I)
ANIMAL_FEED = re.compile(
    r'\b(animals?\s+(food|feed|feeding)|fish|'                  
    r'oilcake|bran|beet-pulp|bagasse|brewing\s+or\s+distilling\s+dregs|'   
    r'of\s+(meat|offal|fish)|'                    
    r'residues?.*of\s+(maize|wheat|rice|cereals?|starch)'
    r')\b',
    re.I
)
INDUSTRIAL_ORGANIC = re.compile(
    r'\b(wine\s+lees?|argol|tartaric|industrial\s+residues?)\b',re.I)

RULES_CN23 = {
    "CN Chapter": "23 (Food industry residues, animal feed, pet food)",
    "patterns": {
        "pet_feed": PET_FEED,
        "animal_feed": ANIMAL_FEED,
        "industrial_organic": INDUSTRIAL_ORGANIC
    },
    "mapping_rules": [
        ("pet_feed", "packaging pet food"),
        ("animal_feed", "packaging animal feed"),
        ("industrial_organic", "packaging industrial organic waste")
    ]
}
# %% 3. Generic rule engine
def apply_rules(rules, heading: str, code: str="") -> str:
    t = clean_negations((heading or "").lower())
    flags = {k: bool(pat.search(t)) for k, pat in rules.get("patterns", {}).items()}
    local_env = dict(flags)
    local_env["code"] = code

    for cond, label in rules["mapping_rules"]:
        try:
            if cond == "Others":   # explicit fallback
                return label
            if eval(cond, {}, local_env):
                return label
        except Exception:
            continue
    return ""

# %% 4. Dispatcher
RULE_SETS = {
    "02": RULES_CN02, "03": RULES_CN03, "04": RULES_CN04, 
    "07": RULES_CN07, "08": RULES_CN08, "09": RULES_CN09,
    "10": RULES_CN10, "11": RULES_CN11, "12": RULES_CN12, "15": RULES_CN15,
    "16": RULES_CN16, "17": RULES_CN17, "18": RULES_CN18, "19": RULES_CN19,
    "20": RULES_CN20, "21": RULES_CN21, "22": RULES_CN22, "23": RULES_CN23,
}

CHAPTER_FUNCS = {
    k: (lambda rules: (lambda c, h, rules=rules: apply_rules(rules, h, code=c)))(rules)
    for k, rules in RULE_SETS.items()
}

# %% 5. Rule-based mapping of all food-related CN chapters (Table S1)
df_result = pd.read_excel("CPA Ver. 2.2 - CN 2025_edited2.xlsx")
keywords = []
for _, row in df_result.iterrows():
    code = str(row["CN2025_Code"])
    heading = str(row.get("CN2025_Self_Text", "")) or ""
    func = CHAPTER_FUNCS.get(code[:2], lambda c, h: "")
    keywords.append(func(code, heading))
df_result["keyword for data scraping"] = keywords

df_result = df_result[df_result["CN2025_Code"].str[:2].isin(RULE_SETS.keys())]

chapter_keyword_counts = (
        df_result.groupby([df_result["CN2025_Code"].str[:2], "keyword for data scraping"])["CN2025_Code"]
        .nunique()
        .rename("n_products")
        .reset_index()
        .rename(columns={"CN2025_Code": "chapter", "keyword for data scraping": "keyword"})
    )
chapter_map = {code: rules["CN Chapter"] for code, rules in RULE_SETS.items()}
chapter_keyword_counts["chapter"] = chapter_keyword_counts["chapter"].map(chapter_map)
    
def pretty_pattern(pat: re.Pattern) -> str:
    raw = pat.pattern # gives the raw regex string
    text = raw

    # 1) Replace ALL negative lookaheads first (allow one (...) level)
    lookahead_re = re.compile(r'\(\?!(?:[^()]|\([^()]*\))*\)') # match (?! … )
    matches = list(lookahead_re.finditer(text))
    for m in matches:
        body = m.group(0)       # e.g. (?!\s+(cheese|powder))  or  (?!coconut(?:s)?\b)
        inner = body[3:-1]      # strip '(?!' and trailing ')'

        # Clean and format the inner content
        cleaned = inner.replace(r'\b', '')
        cleaned = re.sub(r'\\s[\+\*]?', ' ', cleaned).strip()
        if cleaned.startswith('(') and cleaned.endswith(')'):
            cleaned = cleaned[1:-1]
        cleaned = cleaned.replace('|', ', ')
        cleaned = re.sub(r'\s+', ' ', cleaned).strip()

        # Phrase choice
        if inner.lstrip().startswith(r'\s'):
            phrase = f" (not followed by {cleaned})"
        else:
            phrase = f" (not including {cleaned})"

        # Replace this exact lookahead once
        text = text.replace(body, phrase, 1)

    # 2) Optional plural forms like (?:s)? -> (s)
    text = re.sub(r'\(\?:s\)\?', '(s)', text)

    # [optional nicety] Convert bare 's?' at word end to '(s)'
    # so 'groundnuts?' -> 'groundnut(s)' without touching existing '(s)'
    text = re.sub(r'(?<!\))s\?', '(s)', text)

    # 3) Optional character forms like h? -> h/next
    text = re.sub(r'(\w)\?(\w)', r'\1/\2', text)
    
    # 3.5) Handle character-class separators like [-\s]? -> (- or space or none)
    text = re.sub(r'\[-\\s\]\?', '(- or space or none)', text)

    # 4) Simplify non-capturing groups
    text = text.replace('(?:', '(')

    # 5) Remove \b markers
    text = text.replace(r'\b', '')
    
    # 5.5) Replace \s+ (space) sequences with a readable form
    text = re.sub(r'\\s\+', ' (one or more spaces) ', text)
    text = re.sub(r'\\s\*', ' (zero or more spaces) ', text)
    
    # 5.6) Translate dot-star patterns (.*) into a readable form
    text = re.sub(r'\.\*', ' (any text) ', text)
    
    # 6) Use slashes for alternation
    text = text.replace('|', ' / ')

    # 7) Remove leftover escapes
    text = text.replace(r'\\s+', ' ')
    text = text.replace(r'\\', '')

    # 8) Drop redundant outer parentheses
    if text.startswith("(") and text.endswith(")"):
        inner = text[1:-1]
        # only drop if it's a plain alternation (contains / but no "not ...")
        if " / " in inner and "not " not in inner:
            text = inner

    # 9) Normalize spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    text = re.sub(r'\)\?', ')', text)  # mix(?:ture|tures|es)?

    return text


def pattern_glossary(rule_sets):
    rows = []
    for rules in rule_sets.values():
        chapter = rules["CN Chapter"]
        for label, regex in rules.get("patterns", {}).items():
            rows.append({
                "chapter": chapter,
                "pattern_label": label,
                "regex_pattern": regex.pattern,  # clearly a Python regex
                "matched_terms": pretty_pattern(regex),
            })
    return pd.DataFrame(rows, columns=[
        "chapter", "pattern_label", "regex_pattern", "matched_terms"
    ])

def mapping_rules(rule_sets):
    rows = []

    # Build lookup of readable search-term explanations
    term_lookup = {}
    for rules in rule_sets.values():
        chapter = rules["CN Chapter"]
        for label, regex in rules.get("patterns", {}).items():
            term_lookup[(chapter, label)] = pretty_pattern(regex)

    for rules in rule_sets.values():
        chapter = rules["CN Chapter"]
        for cond, keyword in rules.get("mapping_rules", []):
            raw_tokens = re.split(r'\s*(?:\band\b|\bor\b|,)\s*', cond)
            clean_tokens = []
            for t in raw_tokens:
                t = t.strip().lower()
                t = re.sub(r'[\(\)]', '', t)      # remove parentheses
                t = re.sub(r'\bnot\s+', '', t)     # remove 'not '
                if t and t not in clean_tokens:
                    clean_tokens.append(t)

            explanations = []
            for t in clean_tokens:
                if (chapter, t) in term_lookup:
                    explanations.append(f"{t}: {term_lookup[(chapter, t)]}")

            rows.append({
                "chapter": chapter,
                "pattern_label": cond,
                "keyword": keyword,
                "matched_terms": "; ".join(explanations) if explanations else None
            })

    return pd.DataFrame(rows, columns=[
        "chapter", "pattern_label", "keyword", "matched_terms"
    ])

df_glossary = pattern_glossary(RULE_SETS)
df_mapping_rules = mapping_rules(RULE_SETS)
df_origin = pd.read_excel("CPA Ver. 2.2 - CN 2025_edited2.xlsx")

df_mapping_rules = df_mapping_rules.merge(chapter_keyword_counts, on=["chapter", "keyword"], how="left")
df_mapping_rules["n_products"] = df_mapping_rules["n_products"].fillna(0).astype(int)

# --- Compute summary statistics ---
summary_row = {
    "chapter": f"{df_mapping_rules['chapter'].nunique()} unique chapters",
    "pattern_label": f"{df_mapping_rules['pattern_label'].nunique()} unique pattern labels",
    "keyword": f"{df_mapping_rules['keyword'].nunique()} unique keywords",
    "matched_terms": "",
    "n_products": df_mapping_rules["n_products"].sum()
}
# --- Append the summary row at the end ---
df_mapping_rules = pd.concat(
    [df_mapping_rules, pd.DataFrame([summary_row])],
    ignore_index=True
)

chapter_code = "07"  # Change this to any two-digit CN chapter (e.g., "07", "20")
df_chapter = df_mapping_rules[df_mapping_rules["chapter"].str.startswith(chapter_code)]
# --- Add summary row at the end (same logic as full df) ---
summary_row = pd.DataFrame({
    "chapter": [f"{df_chapter['chapter'].nunique()} chapter"],
    "pattern_label": [f"{df_chapter['pattern_label'].nunique()} unique pattern labels"],
    "keyword": [f"{df_chapter['keyword'].nunique()} unique keywords"],
    "matched_terms": [""],
    "n_products": [df_chapter["n_products"].sum()]
})
df_chapter = pd.concat([df_chapter, summary_row], ignore_index=True)

df_result.to_csv("df_result.csv", index=False)

## Generating Table S1
df_mapping_rules.to_csv("./results/df_mapping_rules.csv", encoding="utf-8-sig", index=False)
